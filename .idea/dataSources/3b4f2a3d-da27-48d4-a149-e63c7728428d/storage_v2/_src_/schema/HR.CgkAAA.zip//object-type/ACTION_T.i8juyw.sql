create TYPE ACTION_T 
    AS OBJECT 
    ( 
        SYS_XDBPD$ XDB$RAW_LIST_T , 
        ACTIONED_BY VARCHAR2 (10) , 
        DATE_ACTIONED DATE 
    ) FINAL 
;
/

